//SETUP
var express		= require("express"),
	app			= express(),
	bodyParser	= require("body-parser"),
	mongoose	= require("mongoose"),
	passport	= require("passport"),
	LocalStrategy = require("passport-local")
	//User 		= require("/model/user")


//CONFIG
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));
app.set("view engine", "ejs");
mongoose.connect("mongodb://localhost/storymash1", {useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false, useCreateIndex: true});


//MONGOOSE/MODEL/CONFIG
var UserSchema = new mongoose.Schema({
	username: String,
	password: String
});


var storyAnswerSchema = new mongoose.Schema({
	storyAnswer1: String,
	storyAnswer2: String,
	storyAnswer3: String,
	storyAnswer4: String,
	storyAnswer5: String,
	storyAnswer6: String,
	storyAnswer7: String
}); 

var answerSchema = new mongoose.Schema({
		questionID: Number, answer: String
});


var Storyanswer = mongoose.model("Storyanswer", storyAnswerSchema);
var answer = mongoose.model("answer", answerSchema);



//QUESTIONS TO LOOP THRU NEW/SHOW
var storyQuestions = [
	{questionID: 1, question: "What is your name?"},
	{questionID: 2, question: "Where did you go today?"},
	{questionID: 3, question: "What were you going to do?"},
	{questionID: 4, question: "Who did you see?"},
	{questionID: 5, question: "What did they say to you?"},
	{questionID: 6, question: "What did you say to them?"},
	{questionID: 7, question: "How did it all turn out?"}
	];

//QUESTIONS TO MATCH UP WITH ANSWERS:
//var storyQuestion = [{
//	storyQuestion1: "What is your name?",
//	storyQuestion2: "Where did you go today?",
//	storyQuestion3: "What were you going to do?",
//	storyQuestion4: "Who did you see?",
//	storyQuestion5: "What did they say to you?",
//	storyQuestion6: "What did you say to them?",
//	storyQuestion7: "How did it all turn out?"
//	}];


//ROUTES - 
app.get("/", function(req, res){
	res.render("home");
});

//INDEX 
app.get("/story", function(req, res){
	Storyanswer.find({}, function(err, storyAnswer){
		if(err){
			console.log("Error!");
		} else {
			res.render("index", {storyAnswer: storyAnswer});
		}
	});
});


//NEW Route - displays form to send data to post route
//Get always retrieves data
app.get("/story/new", function(req, res){
res.render("new", {storyQuestions: storyQuestions});
});


//CREATE Route - add new questions to DB
//Post always creates data
app.post("/story", function(req, res){	
	// Create new story and save to DB
	console.log(req.body)
	let arr=[
		
	];
	for (const [key, value] of Object.entries(req.body)) {
 	 console.log(`${key}: ${value}`);
	let obj={questionID: key, answer: value};
		arr.push(obj)
	}
	answer.create(arr, function(err, newStory){
		if(err){
			console.log(err);
//			res.render("new");
		} else {
			console.log(newStory)
			//redirect back to main page
			res.redirect("/story/" + newStory);
		}
	});
	
	// Storyanswer.create(req.body.storyAnswer, function(err, newStory){
	// 	if(err){
	// 		res.render("new");
	// 	} else {
	// 		console.log(newStory._id)
	// 		//redirect back to main page
	// 		res.redirect("/story/" + newStory._id);
	// 	}
	// });
});



//SHOW route - shows one story
app.get("/story/:id", function(req, res){
	//find the story with the provided ID
	Storyanswer.findById(req.params.id, function(err, foundStory){
		if(err){
			console.log(err);
		} else {
			//render show template for that story
			res.render("show", {storyAnswer: foundStory});
		}
	});
});





















//LISTEN
app.listen(3000, function(){
	console.log('The Story Mash Server has started!');
});