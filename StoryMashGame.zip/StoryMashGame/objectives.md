STORY GAME

General Idea:
Online game where several users play with each other.  Each user is asked a series of questions and the full story is returned.  However, the answers between the users have been mixed to make a mixed up story.

Major Objectives:
Phase 1: One Device
- Create interface for users to answer a series of questions, in random order (users will. Have one device that is passed around to each player)
- Have answered stored in a database
- Have the answers returned, in proper order.
- Fun looking interface, maybe with music or sound affects
Phase 2: Multiple Devices
- Create interface for users to answer a series of questions
- Have answered stored in a database
- Have the answers returned, but each questions will be returned by a random user.
- Repeat return for number of users in the game
    - (For example - if 5 players, then 5 random stories returned)

User Interface:
Welcome page
- Instructions text
- Asking for number of players input form
- Begin game button

Questions/Game page
- First questions displayed, input form, submit button
- Second question displayed, input form, submit button
- Repeat for 7 questions
- On last question, final submit button

Waiting Page
- When hit submit button, put on waiting page until all users have hit submit

Story Result Page
- First question is displayed, on click random answer 1 appears
- On click, second question is displayed, on click random answer 2 appears
- Repeat for all 7 questions
- On last question, button for Show Next Story
- After last story, End Game

Game Over page
- Play again button 
    - Back to welcome page
- End game button
    - Thanks for playing page

Action Items:
Phase 1: One Device (players pass device around room)
Phase 2: Multiple Devices (players login and use own device)
Phase 3: Nice to have


Welcome Page
Phase 1: One Device
- Basic HMTL Welcome text
- Begin game button redirects to one device questions
Phase 2: Multiple Devices
- Number of Players button
- Some kind of “login” to connect users to same database
- For multiple players, Begin Game redirects player to own questions

Questions Page
Phase 1: One Device
- Input form with random Question 1
- Store answer in database
- Input form for random Questions 2-7
- As a question is answered, that questions and response disappears and next question appears.
- Store answers in database
- Final submit button
Phase 2: Multiple Devices
- Input form for questions 1-7 in proper order
- Answers for multiple users are stored in same database
Phase 3: Nice to have
- Set limit on time to answer questions before proceeding to next
- If no answer given in time allowed, get Random answer from API
- Find Random “whatever” APIs

Waiting Page:
Phase 1: One Device
- N/A
Phase 2: Multiple Users
- Holding page until all users have submitted final answers

Story Results Page:
Phase 1: One Device
- Print question one
- “Reveal” answer button
- “Reveal” prints input for question one
- “Next” button
- “Next” prints question 2
- “Reveal prints input for question two
- (Repeat for all seven questions)
- “Play Again” - redirects to Welcome Page
- “Game Over” - redirect to Game Over page
Phase 2: Multiple Devices
- Print Random Answer 1
- Print Random Answer 2
- (Repeat)
- “Next Story” button - clears page and begins again
- Need to make sure returns random answer only once
- If

Phase 3: Maybe add later:
- while waiting for player to answer question, have host saying snarky things
- Add animated gifs for each type question
- Opening image is two different looking characters that “mash” into each other creating a hybrid (“like yin & yang, sort of)


