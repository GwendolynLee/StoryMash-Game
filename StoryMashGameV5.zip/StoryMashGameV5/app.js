//VERSION 5 IS ATTEMPTING TO REGISTER WITHOUT A PASSWORD

//SETUP
var express 	= require("express"),
	app 		= express(),
	bodyParser 	= require("body-parser"),
	mongoose 	= require("mongoose"),
	flash		= require("connect-flash"),
	Game		= require("./models/game"),
	Story		= require("./models/story"),
	User		= require("./models/user"),
	seedDB		= require("./seeds")

//Requiring Routes
var gameRoutes  = require("./routes/game"),
	storyRoutes = require("./routes/story"),
	indexRoutes  = require("./routes/index")


//CONFIG
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.static("public"));
app.set("view engine", "ejs");
app.use(flash());
mongoose.connect("mongodb://localhost/storymash1", {useNewUrlParser: true, useUnifiedTopology: true, useFindAndModify: false, useCreateIndex: true});


app.use(require("express-session")({
	secret: "Hey you guys!",
	resave: false,
	saveUninitialized: false
}));


app.use(function(req, res, next){
	res.locals.currentUser = req.user;
	next();
});

app.use(indexRoutes);
app.use(gameRoutes);
app.use(storyRoutes);






//LISTEN
app.listen(3000, function(){
	console.log('The Story Mash Server has started!');
});