var express = require("express");
var router = express.Router();
var User = require("../models/user");

//=================
//HOME PAGE
//=================

//Root Route
router.get("/", function(req, res){
	res.render("home");
});


//=================
//AUTH ROUTES
//=================

//New - Show register form
router.get("/register", function(req, res){
	res.render("register");
});

//CREATE - add new user to DB (Handle sign up logic)
router.post("/register", function(req, res){
	var newUser = new User({username: req.body.username});
	User.create(newUser, function(err, user){
		if(err){
			console.log(err);
			return res.render("register")
		}
//		passport.authenticate("local")(req, res, function(){
			res.redirect("/");
//		});
	});
});

//NEW - Show login form
router.get("/login", function(req, res){
	res.render("login");
});

//Handle login logic
router.post("/login", 
	// 	passport.authenticate("local",
	// {
	// 	successRedirect: "/",
	// 	failureRedirect: "/login"
	// }), 
		function(req, res){
});


//Log Out Route
router.get("/logout", function(req, res){
	req.logout();
	res.redirect("/");
});

//Middleware
function isLoggedIn(req, res, next){
	if(req.isAuthenticated()){
		return next();
	} 
	req.flash("error", "Please create player first")
	res.redirect("/login");
}

module.exports = router;