STORY GAME

V5 - Previous versions require the User to enter a username and password.  I am attemping to remove all the Passport code in order so that the User will only need to enter a username.

