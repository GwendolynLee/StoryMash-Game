var mongoose = require("mongoose");

var questionSchema = mongoose.Schema({
	question: String,
});

var question = [
	"What is your name?",
	"Where did you go today?",
	"What were you going to do?",
	"Who did you see?",
	"What did they say to you?",
	"What did you say to them?",
	"How did it all turn out?"
	];


module.exports = mongoose.model("Questions", questionSchema);


