var mongoose = require("mongoose");
var passportLocalMongoose = require("passport-local-mongoose");

var UserSchema = new mongoose.Schema({
	gameId: String,
	storyId: String,
	answers: {
		answerInput1: String,
		answerInput2: String,
		answerInput3: String,
		answerInput4: String,
		answerInput5: String,
		answerInput6: String,
		answerInput7: String,
	}
});

UserSchema.plugin(passportLocalMongoose);

module.exports = mongoose.model("User", UserSchema);