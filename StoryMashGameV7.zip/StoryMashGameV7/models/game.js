var mongoose = require("mongoose");

var gameSchema = new mongoose.Schema({
	gameName: String,
	numPlayers: Number,
	story: String
	// stories: [
	// 	{
	// 		type: mongoose.Schema.Types.ObjectId,
	// 		ref: "Story"
	// 	}
	// ]
});

module.exports = mongoose.model("Game", gameSchema);