var express = require("express");
var router = express.Router();
var Game = require("../models/game");
var Story = require("../models/story");
var Questions = require("../models/questions");
var middleware = require("../middleware");
var	randomWords = require("random-words");


// var questionSchema = new mongoose.Schema({
// 	question: String,
// });

// var Questions = mongoose.model("Questions", questionSchema);

var questions = [
	"What is your name?",
	"Where did you go today?",
	"What were you going to do?",
	"Who did you see?",
	"What did they say to you?",
	"What did you say to them?",
	"How did it all turn out?"
	];

// Questions.create([
// 	{question: "What is your name?"},
// 	{question: "Where did you go today?"},
// 	{question: "What were you going to do?"},
// 	{question: "Who did you see?"},
// 	{question: "What did they say to you?"},
// 	{question: "What did you say to them?"},
// 	{question: "How did it all turn out?"},
// 	])



// ===============================
// GAME ROUTES
// ===============================

//INDEX - SHOW All Games
router.get("/game", function(req, res){
	// get all games for db
	Game.find({}, function(err, allGames){
		if(err){
			console.log(err);
		} else {
			res.render("games/index", {games: allGames, currentUser: req.user});	
		}
	});
});

//CREATE - Add New Game to DB
router.post("/game", middleware.isLoggedIn, function(req, res){
	//get data from form and add to game array
	var gameName = req.body.gameName;
	var numPlayers = req.body.numPlayers;
	var newGame = {gameName: gameName, numPlayers: numPlayers}
	// create a new game and save to DB
	Game.create(newGame, function(err, newlyCreated){
		if(err){
			console.log(err);
		} else {
			//redirect to game page
			res.redirect("/game")
		}
	});
});

//NEW - Show Form to Create New Game
router.get("/game/new", middleware.isLoggedIn, function(req, res){
	res.render("games/new");
});

//SHOW - One Game
router.get("/game/:id", function(req, res){
	//find game with provided ID
	Game.findById(req.params.id).populate("stories").exec(function(err, foundGame){
		if(err){
			console.log(err);
		} else {
			console.log(foundGame);
			//render show template for that one game
			// foundGame.stories = foundGame.stories[1]
			//console.log(foundGame.stories[0])
			// let obj = {
			// 	_id: foundGame._id, gameName: foundGame.gameName, numPlayers: foundGame.numPlayers, stories: foundGame.stories[1]
			// }
			res.render("games/show", {game: foundGame, questions: questions});	
			// res.render("games/show", {game: obj, questions: questions});	

		}
	});
});

//get a random record from all stories in MongoDB
//db.stories.aggregate([{$sample:{size:1}}]).pretty();

//get random record from all strories from one particualar Game ID in Mongodob


//add random record to GET route

//tell that random record to print in the show template

module.exports = router;
