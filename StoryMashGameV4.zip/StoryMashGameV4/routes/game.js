var express = require("express");
var router = express.Router();
var Game = require("../models/game");
var middleware = require("../middleware");


// ===============================
// GAME ROUTES
// ===============================

//INDEX - SHOW All Games
router.get("/game", function(req, res){
	// get all games for db
	Game.find({}, function(err, allGames){
		if(err){
			console.log(err);
		} else {
			res.render("games/index", {games: allGames, currentUser: req.user});	
		}
	});
});

//CREATE - Add New Game to DB
router.post("/game", middleware.isLoggedIn, function(req, res){
	//get data from form and add to game array
	var gameName = req.body.gameName;
	var numPlayers = req.body.numPlayers;
	var newGame = {gameName: gameName, numPlayers: numPlayers}
	// create a new game and save to DB
	Game.create(newGame, function(err, newlyCreated){
		if(err){
			console.log(err);
		} else {
			//redirect to game page
			res.redirect("/game")
		}
	});
});

//NEW - Show Form to Create New Game
router.get("/game/new", middleware.isLoggedIn, function(req, res){
	res.render("games/new");
});

//SHOW - One Game
router.get("/game/:id", function(req, res){
	//find game with provided ID
	Game.findById(req.params.id).populate("stories").exec(function(err, foundGame){
		if(err){
			console.log(err);
		} else {
			console.log(foundGame);
			//render show template for that one game
			res.render("games/show", {game: foundGame});	
		}
	});
});



module.exports = router;
