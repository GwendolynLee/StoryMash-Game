var express = require("express");
var router = express.Router();
var passport = require("passport");
var User = require("../models/user");

//=================
//HOME PAGE
//=================

//Root Route
router.get("/", function(req, res){
	// res.render("home", {currentUser: req.user});
	res.render("home");
});


//=================
//AUTH ROUTES
//=================

//Show register form
router.get("/register", function(req, res){
	res.render("register");
});

//Handle sign up logic
router.post("/register", function(req, res){
	var newUser = new User({username: req.body.username});
	User.register(newUser, req.body.password, function(err, user){
		if(err){
			console.log(err);
			req.flash("failure", "Player name already taken");
			return res.render("register")
		}
		passport.authenticate("local")(req, res, function(){
			res.redirect("/");
		});
	});
});

//Show login form
router.get("/login", function(req, res){
	res.render("login");
});

//Handle login logic
router.post("/login", passport.authenticate("local",
	{
		successRedirect: "/",
		failureRedirect: "/login"
	}), function(req, res){
});


//Log Out Route
router.get("/logout", function(req, res){
	req.logout();
	res.redirect("/");
});

//Middleware
function isLoggedIn(req, res, next){
	if(req.isAuthenticated()){
		return next();
	} 
	req.flash("error", "Please create player first")
	res.redirect("/login");
}

module.exports = router;