var mongoose = require("mongoose");

var gameSchema = new mongoose.Schema({
	gameName: String,
	numPlayers: Number,
	stories: [
		{
			type: mongoose.Schema.Types.ObjectId,
			ref: "Story"
		}
	]
});

module.exports = mongoose.model("Game", gameSchema);