var mongoose = require("mongoose");

var questionSchema = mongoose.Schema({
	storyQuestion1: String,
	storyQuestion2: String,
	storyQuestion3: String,
	storyQuestion4: String,
	storyQuestion5: String,
	storyQuestion6: String,
	storyQuestion7: String
});

// var questions = questions[{
// 	storyQuestion1: "What is your name?",
// 	storyQuestion2: "Where did you go today?",
// 	storyQuestion3: "What were you going to do?",
// 	storyQuestion4: "Who did you see?",
// 	storyQuestion5: "What did they say to you?",
// 	storyQuestion6: "What did you say to them?",
// 	storyQuestion7: "How did it all turn out?"
// 	}];

module.exports = mongoose.model("Questions", questionSchema);

//**********************************************************
//OLD STUFF
// var storyAnswerSchema = new mongoose.Schema({
// 	storyAnswer1: String,
// 	storyAnswer2: String,
// 	storyAnswer3: String,
// 	storyAnswer4: String,
// 	storyAnswer5: String,
// 	storyAnswer6: String,
// 	storyAnswer7: String
// }); 

// var answerSchema = new mongoose.Schema({
// 		questionID: Number, answer: String
// });

// var Storyanswer = mongoose.model("Storyanswer", storyAnswerSchema);
// var answer = mongoose.model("answer", answerSchema);

// //QUESTIONS TO LOOP THRU NEW/SHOW
// var storyQuestions = [
// 	{questionID: 1, question: "What is your name?"},
// 	{questionID: 2, question: "Where did you go today?"},
// 	{questionID: 3, question: "What were you going to do?"},
// 	{questionID: 4, question: "Who did you see?"},
// 	{questionID: 5, question: "What did they say to you?"},
// 	{questionID: 6, question: "What did you say to them?"},
// 	{questionID: 7, question: "How did it all turn out?"}
// 	];

//QUESTIONS TO MATCH UP WITH ANSWERS:
//var storyQuestion = [{
//	storyQuestion1: "What is your name?",
//	storyQuestion2: "Where did you go today?",
//	storyQuestion3: "What were you going to do?",
//	storyQuestion4: "Who did you see?",
//	storyQuestion5: "What did they say to you?",
//	storyQuestion6: "What did you say to them?",
//	storyQuestion7: "How did it all turn out?"
//	}];
