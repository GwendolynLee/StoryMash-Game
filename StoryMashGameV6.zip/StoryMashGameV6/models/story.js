var mongoose = require("mongoose");

var storySchema = mongoose.Schema({
	storyAnswer1: String,
	storyAnswer2: String,
	storyAnswer3: String,
	storyAnswer4: String,
	storyAnswer5: String,
	storyAnswer6: String,
	storyAnswer7: String,
	author: {
		id: {
			type: mongoose.Schema.Types.ObjectId,
			ref: "User"
		},
		username: String,
	},
	questions: {
		type: mongoose.Schema.Types.ObjectId,
		ref: "Questions"
	}
});

module.exports = mongoose.model("Story", storySchema);