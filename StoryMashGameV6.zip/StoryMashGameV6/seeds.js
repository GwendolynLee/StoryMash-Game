var mongoose = require("mongoose");
var Game = require("./models/game");
var Story = require("./models/story");

//starter data, matches model
var data = [
	{gameName: "blue-game", numPlayers: 5},
	{gameName: "orange-game", numPlayers: 6},
	{gameName: "yellow-game", numPlayers: 3},
]

function seedDB(){
	//Remove all games from DB
	Game.deleteMany({}, function(err){
		
		if(err){
			console.log(err);
		} else
		console.log("removed games!");
		//add a few games, loop through data, create game for each one, seed represents one of the games in data array
		data.forEach(function(seed){
			Game.create(seed, function (err, game){
				if(err){
					console.log(err)
				} else {
					console.log("added a new game!");
					//create a story
					Story.create(
						{
							storyAnswer1: "Chester Copperpot",
							storyAnswer2: "the wishing well",
							storyAnswer3: "to search for treasure",
							author: "Betty"
						}, function(err, story){
							if(err) {
								console.log(err);
							} else {
								game.stories.push(story);
								game.save();
								console.log("created new story");
							} 
					});
				}
			});
		});
		
	});
}

//sends the function seedDB out, the stored in app.js seedDB, then executed with app.js seedDB
module.exports = seedDB;