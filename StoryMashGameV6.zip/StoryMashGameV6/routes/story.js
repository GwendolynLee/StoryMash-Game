var express = require("express");
var router = express.Router();
var Game = require("../models/game");
var Story = require("../models/story");
var Questions = require("../models/questions");
var middleware = require("../middleware");

//===============================
// STORY ROUTES
// ===============================

//NEW Story
router.get("/game/:id/story/new", middleware.isLoggedIn, function(req, res){
	var questions = [
		{storyQuestion1: "What is your name?",
		storyQuestion2: "Where did you go today?",
		storyQuestion3: "What were you going to do?",
		storyQuestion4: "Who did you see?",
		storyQuestion5: "What did they say to you?",
		storyQuestion6: "What did you say to them?",
		storyQuestion7: "How did it all turn out?"}
	];
		//find game by id
	Game.findById(req.params.id, function(err, game){
		if(err){
			console.log(err);
		} else {
			res.render("stories/new", {game: game, questions: questions});
		}
	});
});

//CREATE Story
router.post("/game/:id/story", middleware.isLoggedIn, function(req, res){
	//look up game using ID
	var questions = req.body.questions;
	Game.findById(req.params.id, function(err, game){
		if(err){
			console.log(err);
			res.redirect("/game");
		} else {	
			//create new story 
			Story.create(req.body.story, function(err, story){
				if(err){
					console.log(err);
				} else {
					//add username and id to comment
					story.author.id = req.user._id;
					story.author.username = req.user.username;
					console.log("New story's username will be: " + req.user.username);
					//save comment
					story.save();
					//connect new story to game
					game.stories.push(story);
					game.save();
					console.log(story);
					//redirect to game show page
					res.redirect("/game/" + game._id);
				}
			});
		}
	});
});


module.exports = router;